# Math 449 Numerical Applied Mathematics at WUSTL

## Tentative material
[https://scaomath.github.io/teaching/fall2020-math449](https://scaomath.github.io/teaching/fall2020-math449)

## Primer on Python 3
[https://www.kaggle.com/learn/python](https://www.kaggle.com/learn/python)

## Structure of this repo
```bash
├── Homework
│   ├── imports needed
│  
├── Lectures file
├── Office hour files
│   ├── codes during live stream

```
